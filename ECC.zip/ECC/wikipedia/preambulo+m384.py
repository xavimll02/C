import hashlib

preambulo = 64*'20'
preambulo += ''.join(format(ord(c),'x') for c in 'TLS 1.3, server CertificateVerify')
preambulo += '00'

m = open("mensaje.bin", 'rb')
m384 = hashlib.sha384(m.read())
mensaje = preambulo + m384.hexdigest()
mensaje = hashlib.sha256(bytes.fromhex(mensaje))
print(mensaje.hexdigest())


