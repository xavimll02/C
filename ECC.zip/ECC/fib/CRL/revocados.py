fichero = open("listaCertificadosRevocados.txt", "r")
texto = fichero.read()

nCertificadosRevocados = texto.count("Serial Number:")
print("Numero de certificados revocados:", nCertificadosRevocados)


