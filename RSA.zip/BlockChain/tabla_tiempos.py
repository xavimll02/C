from sympy import *
from Crypto.PublicKey import RSA
import random
import time

# Apartado tabla comparativa:

def sign(message, dp, dq, p, q, qinv, n):
    c = message
    s1 = pow(c, dp, p)
    s2 = pow(c, dq, q)
    return (s2 + q * (((s1 - s2) * qinv) % p)) % n

def sign_slow(message, d, n):
    c = message
    return pow(c, d, n)

start_time = 0
t_tcr = 0
t = 0

p = 12624541170508796983315343010775468996076108162965336104931758835115748124546563786469356827239605247939767174360255735117043538162549865652628944502956709
q = 6746265151378834420011211085584376121749799607300357182535066377926520420963393554201633487360509183214517545044992527878526254429283146042015181168122623
n = p * q
e = (2**16)+1
phi = (p - 1) * (q - 1)
d = mod_inverse(e, phi)
dp = d % (p - 1)
dq = d % (q - 1)
qinv = mod_inverse(q, p)

for i in range(100):

    m = random.randint(0,2**512)
    start_time = time.time()
    s = sign(m, dp, dq, p, q, qinv, n)
    t_tcr += time.time() - start_time

    start_time = time.time()
    s = sign_slow(m, d, n)
    t += time.time() - start_time

print("512 bits, TCR: " + str(t_tcr))
print("512 bits, T: " + str(t))

t_tcr = 0
t = 0
RSAkey = RSA.generate(1024)
n = RSAkey.n
p = RSAkey.p
q = RSAkey.q
e = RSAkey.e
phi = (p - 1) * (q - 1)
d = RSAkey.d  
dp = d % (p - 1) 
dq = d % (q - 1) 
qinv = mod_inverse(q, p)

for i in range(100):

    m = random.randint(0,2**1024)
    start_time = time.time()
    s = sign(m, dp, dq, p, q, qinv, n)
    t_tcr += time.time() - start_time

    start_time = time.time()
    s = sign_slow(m, d, n)
    t += time.time() - start_time

print("1024 bits, TCR: " + str(t_tcr))
print("1024 bits, T: " + str(t))

t_tcr = 0
t = 0
RSAkey = RSA.generate(2048)
n = RSAkey.n
p = RSAkey.p
q = RSAkey.q
e = RSAkey.e
phi = (p - 1) * (q - 1)
d = RSAkey.d  
dp = d % (p - 1) 
dq = d % (q - 1) 
qinv = mod_inverse(q, p)

for i in range(100):

    m = random.randint(0,2**2048)
    start_time = time.time()
    s = sign(m, dp, dq, p, q, qinv, n)
    t_tcr += time.time() - start_time

    start_time = time.time()
    s = sign_slow(m, d, n)
    t += time.time() - start_time

print("2048 bits, TCR: " + str(t_tcr))
print("2048 bits, T: " + str(t))

t_tcr = 0
t = 0
RSAkey = RSA.generate(4096)
n = RSAkey.n
p = RSAkey.p
q = RSAkey.q
e = RSAkey.e
phi = (p - 1) * (q - 1)
d = RSAkey.d  
dp = d % (p - 1) 
dq = d % (q - 1) 
qinv = mod_inverse(q, p)

for i in range(100):

    m = random.randint(0,2**4096)
    start_time = time.time()
    s = sign(m, dp, dq, p, q, qinv, n)
    t_tcr += time.time() - start_time

    start_time = time.time()
    s = sign_slow(m, d, n)
    t += time.time() - start_time

print("4096 bits, TCR: " + str(t_tcr))
print("4096 bits, T: " + str(t))
