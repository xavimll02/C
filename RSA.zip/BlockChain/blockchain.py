from sympy import *
from Crypto.PublicKey import RSA
import random
import hashlib
import pickle

class rsa_key:

    # Genera una clave RSA (de 2048 bits y exponente publico 2**16+1 por defecto)
    def __init__(self,bits_modulo=2048,e=2**16+1):

        RSAkey = RSA.generate(bits_modulo)
        self.publicExponent = e # Entero
        self.primeP = RSAkey.p # Entero
        self.primeQ = RSAkey.q # Entero
        phi = (self.primeP - 1) * (self.primeQ - 1)
        self.privateExponent = mod_inverse(e, phi)  # Entero
        self.modulus = self.primeP * self.primeQ # Entero
        self.privateExponentModulusPhiP = self.privateExponent % (self.primeP - 1) # Entero, congruente con privateExponent mod primeP-1
        self.privateExponentModulusPhiQ = self.privateExponent % (self.primeQ - 1) # Entero, congruente con privateExponent mod primeQ-1
        self.inverseQModulusP = mod_inverse(self.primeQ, self.primeP) # Entero, inverso de primeQ mod primeP

    # Salida: un entero que es la firma de "message" hecha con la clave RSA usando el TCR
    def sign(self, message):

        c = message
        s1 = pow(c, self.privateExponentModulusPhiP, self.primeP)
        s2 = pow(c, self.privateExponentModulusPhiQ, self.primeQ)
        return (s2 + self.primeQ * (((s1 - s2) * self.inverseQModulusP) % self.primeP)) % self.modulus

    # Salida: un entero que es la firma de "message" hecha con la clave RSA sin usar el TCR
    def sign_slow(self,message):

        c = message
        return pow(c, self.privateExponent, self.modulus)

class rsa_public_key:

    # Genera la clave publica RSA asociada a la clave RSA "rsa_key"
    def __init__(self, rsa_key):
        self.publicExponent = rsa_key.publicExponent # Exponente publico clave rsa_key
        self.modulus = rsa_key.modulus # Modulo clave rsa_key

    # Salida: True si "signature" se corresponde con la firma de "message" hecha con
    # la clave RSA asociada a la clave publica RSA. False en caso contrario.
    def verify(self, message, signature):

        if pow(signature, self.publicExponent, self.modulus) == message:
            return True
        else:
            return False

class transaction: # Valida si signature^publicExponent congruente con message mod modulus

    # Genera una transaccion firmando "message" con la clave "RSAkey"
    def __init__(self, message, RSAkey): # RSAkey es la clave con que se firma transaccion
        self.public_key = rsa_public_key(RSAkey) # Clave publica RSA correspondiente a RSAkey
        self.message = message # Documento que se firma en la transaccion representado por un entero
        self.signature = RSAkey.sign(message) # Firma de message hecha con RSAkey representada por un entero

    # Salida: True si "signature" se corresponde con la firma de "message" hecha con la
    # clave RSA asociada a la clave publica RSA. False en caso contrario.
    def verify(self):
        if self.public_key.verify(self.message, self.signature):
            return True
        else:
            return False

class block: # Valido si transaccion es valida y su hash h satisface la condicion h < 2^(256-d). d = 16

    # Crea un bloque (no necesariamente valido)
    def __init__(self):

        self.previous_block_hash = -1 # SHA256 del bloque anterior representado por un entero
        self.transaction = transaction(0, rsa_key()) # Transaccion valida
        self.seed = 0 # Entero
        self.block_hash = (2**240) + 1 # SHA256 del bloque actual representado por un entero

    # Devuelve el hash de un bloque
    def hash(self, block):

        entrada = str(block.previous_block_hash)
        entrada = entrada + str(block.transaction.public_key.publicExponent)
        entrada = entrada + str(block.transaction.public_key.modulus)
        entrada = entrada + str(block.transaction.message)
        entrada = entrada + str(block.transaction.signature)
        entrada = entrada + str(block.seed)
        return int(hashlib.sha256(entrada.encode()).hexdigest(), 16) # SHA256 del bloque actual representado por un entero

    # Genera el primer bloque de una cadena con la transaccion "transaction" que se
    # caracteriza por previous_block_hash = 0 y ser valido
    def genesis(self, transaction):

        InitialBlock = block()
        InitialBlock.previous_block_hash = 0
        InitialBlock.transaction = transaction
        InitialBlock.seed = random.randint(0,(2**256)-1)
        InitialBlock.block_hash = hash(InitialBlock)

        if InitialBlock.verify_block():
            return InitialBlock
        else:
            return self.genesis(transaction)

    # Genera un bloque valido siguiente al actual con la transaccion "transaction"
    def next_block(self, transaction):

        NextBlock = block()
        NextBlock.previous_block_hash = self.block_hash
        NextBlock.transaction = transaction
        NextBlock.seed = random.randint(0,(2**256)-1)
        NextBlock.block_hash = hash(NextBlock)

        if NextBlock.verify_block():
            return NextBlock
        else:
            return self.next_block(transaction)

    # Verifica si un bloque es valido:
    # - Comprueba que el hash del bloque anterior cumple las condiciones exigidas
    # - Comprueba que la transaccion del bloque es valida
    # - Comprueba que el hash del bloque cumple las condiciones exigidas
    # Salida: True si todas las comprobaciones son correctas. False en caso contrario.
    def verify_block(self):

        if (self.previous_block_hash < (2**240)) and (self.block_hash < (2**240)) and (self.transaction.verify()):
            return True
        else:
            return False

class block_chain:

    # Genera una cadena de bloques que es una lista de bloques, el primer bloque
    # es un bloque "genesis" generado con la transaccion "transaction"
    def __init__(self, transaction):
        self.list_of_blocks = [block().genesis(transaction)]

    # Anade a la cadena un nuevo bloque valido generado con la transaccion "transaction"
    def add_block(self, transaction):
        self.list_of_blocks.append(self.list_of_blocks[len(self.list_of_blocks)-1].next_block(transaction))

    # Verifica si la cadena de bloques es valida:
    # - Comprueba que todos los bloques son validos
    # - Comprueba que el primer bloque es un bloque "genesis"
    # - Comprueba que para cada bloque de la cadena el siguiente es correcto

    # Salida: el booleano True si todas las comprobaciones son correctas. En caso
    # contrario, False y un entero correspondiente al ultimo bloque valido
    def verify(self):

        for i in range(len(self.list_of_blocks)):

            if i == 0 and self.list_of_blocks[i].previous_block_hash != 0:
                return False, i-1
            if not self.list_of_blocks[i].verify_block():
                return False, i-1

        return True

transaccion = transaction(0, rsa_key())
blockchain_100 = block_chain(transaccion)
for i in range(99):
    print("HOLA")
    transaccion = transaction(0, rsa_key())
    blockchain_100.add_block(transaccion)

with open("100validos", "wb") as file:
    pickle.dump(blockchain_100, file)

transaccion = transaction(0, rsa_key())
blockchain_42 = block_chain(transaccion)

for i in range(41):

    transaccion = transaction(0, rsa_key())
    blockchain_42.add_block(transaccion)

for i in range(58):

    bloque_novalido = block()
    blockchain_42.list_of_blocks.append(bloque_novalido)

with open("42validos", "wb") as file:
    pickle.dump(blockchain_42, file)
