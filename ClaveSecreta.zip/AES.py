from Crypto.Cipher import AES

key_file = open("AES_xavier.marti.llull_2022_09_29_11_10_21.key","rb")
nonce_file = open("AES_xavier.marti.llull_2022_09_29_11_10_21.iv","rb")
ciphertext_file = open("AES_xavier.marti.llull_2022_09_29_11_10_21.enc","rb")
key = b"".join(key_file)
nonce = b"".join(nonce_file)
ciphertext = b"".join(ciphertext_file)
cipher = AES.new(key, AES.MODE_CFB, nonce)
plaintext = cipher.decrypt(ciphertext)
plaintext_file = open("plaintext", "wb")
plaintext_file.write(plaintext)