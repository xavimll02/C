import struct
import numpy as np
import matplotlib.pyplot as plt
from typing import List

# Finite field 2^32
class F2_32:
    def __init__(self, val: int):
        assert isinstance(val, int)
        self.val = val
    def __add__(self, other):
        return F2_32((self.val + other.val) & 0xffffffff)
    def __xor__(self, other):
        return F2_32(self.val ^ other.val)
    def __lshift__(self, nbit: int):
        left  = (self.val << nbit%32) & 0xffffffff
        right = (self.val & 0xffffffff) >> (32-(nbit%32))
        return F2_32(left | right)
    def __repr__(self):
        return hex(self.val)
    def __int__(self):
        return int(self.val)

def quarter_round(a: F2_32, b: F2_32, c: F2_32, d: F2_32):
    a += b; d ^= a; d <<= 16;
    c += d; b ^= c; b <<= 12;
    a += b; d ^= a; d <<= 8;
    c += d; b ^= c; b <<= 7;
    return a, b, c, d

def Qround(state: List[F2_32], idx1, idx2, idx3, idx4):
    state[idx1], state[idx2], state[idx3], state[idx4] = \
        quarter_round(state[idx1], state[idx2], state[idx3], state[idx4])

def inner_block(state: List[F2_32]):

    Qround(state, 0, 4, 8, 12)
    Qround(state, 1, 5, 9, 13)
    Qround(state, 2, 6, 10, 14)
    Qround(state, 3, 7, 11, 15)
    Qround(state, 0, 5, 10, 15)
    Qround(state, 1, 6, 11, 12)
    Qround(state, 2, 7, 8, 13)
    Qround(state, 3, 4, 9, 14)
    return state

def serialize(state: List[F2_32]) -> List[bytes]:
    return b''.join([ struct.pack('<I', int(s)) for s in state ])

def chacha20_block(key: bytes, counter: int, nonce: bytes) -> bytes:
    # make a state matrix
    constants = [F2_32(x) for x in struct.unpack('<IIII', b'expand 32-byte k')]
    key       = [F2_32(x) for x in struct.unpack('<IIIIIIII', key)]
    counter   = [F2_32(counter)]
    nonce     = [F2_32(x) for x in struct.unpack('<III', nonce)]
    state = constants + key + counter + nonce
    initial_state = state[:]
    for i in range(10):
        state = inner_block(state)
    state = [ s + init_s for s, init_s in zip(state, initial_state) ]
    return serialize(state)

def differences(estado1, estadoi):

    count = 0
    for i in range(0,len(estado1)):
        if(estado1[i] != estadoi[i]):
            count += 1
    return count

def chacha20_encrypt(key: bytes, counter: int, nonce: bytes):

    diferencias = {}
    estado1 = ""
    for i in range(0,4096):
        key_stream = chacha20_block(key, counter+i, nonce)

        if i == 0:
            estado1 = key_stream.hex()
            length = len(estado1) * 4
            estado1 = int(estado1, base=16)
            estado1 = str(bin(estado1))[2:].zfill(length)
        else:
            estadoi = key_stream.hex()
            length = len(estadoi) * 4
            estadoi = int(estadoi, base=16)
            estadoi = str(bin(estadoi))[2:].zfill(length)
            if not differences(estado1,estadoi) in diferencias:
                diferencias[differences(estado1,estadoi)] = 1
            else:
                diferencias[differences(estado1,estadoi)] += 1

    return diferencias

lista = chacha20_encrypt(b'\x1C\x92\x40\xA5\xEB\x55\xD3\x8A\xF3\x33\x88\x86\x04\xF6\xB5\xF0\x47\x39\x17\xC1\x40\x2B\x80\x09\x9D\xCA\x5C\xBC\x20\x70\x75\xC0',1,b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02')
lista = dict(sorted(lista.items()))
print(lista)
claves = list(lista.keys())
valores = list(lista.values())
fig, ax = plt.subplots()
ax.bar(claves,valores)
plt.xlabel("Número de bits que han cambiado")
plt.ylabel("Frecuencias")
plt.title("Frecuencias número bits cambiantes estado Chacha20 para counter=(2...4096) respecto counter=1")
plt.show()




