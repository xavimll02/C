import time

# Entrada:
# Salida: tablas exponencial y logaritmo, la primera tal que en la posicion i
#         tiene g^i y la segunda tal que en la posicion a tiene una i tal que
#         a = g^i. (g generador del cuerpo finito representado por entero entre 0 y 255).
def GF_tables():

    tablaExp = {0:1}
    tablaLog = {}
    for i in range(1,256):
        tablaExp[i] = GF_product_p(tablaExp[i-1], 6)
        tablaLog[tablaExp[i-1]] = i-1

    return (tablaExp, dict(sorted(tablaLog.items())))

# Entrada: a elemento del cuerpo representado por un entero entre 0 y 255
# Salida: 0 si a = 0, inverso de a en el cuerpo si a != 0 representado por un entero
#         entre 1 y 255
def GF_invers(a):

    if a == 0:
        return 0

    i = tablaLog[a]
    return tablaExp[255-i]

# Entrada: a y b elementos del cuerpo representados por enteros entre 0 y 255
# Salida: un elemento del cuerpo representado por un entero entre 0 y 255 que es el
#         producto en el cuerpo de a y b calculado usando las tablas exponencial y logaritmo
def GF_product_t(a,b):

    if a == 0 or b == 0:
        return 0

    i = tablaLog[a] + tablaLog[b]
    if i > 255:
        return tablaExp[i - 255]
    else:
        return tablaExp[i]

# Entrada: a y b elementos del cuerpo representados por enteros entre 0 y 255
# Salida: un elemento del cuerpo representado por un entero entre 0 y 255 que
#         es el producto en el cuerpo de a y b calculado usando la definicion
#         en terminos de polinomios
def GF_product_p(a,b):

    suma = 0
    # Desplazamos a "peso del bit de mayor peso de b" veces y acumulamos
    # el resultado de esta multiplicacion en suma con una xor. A continuacion le
    # quitamos a b el bit de mayor peso para dar paso al siguiente bit de mayor peso
    while (b > 0):

        suma ^= a << len(bin(b)[2:]) - 1
        b -= 2**(len(bin(b)[2:]) - 1)

    m = 395 # m = x8 + x7 + x3 + x + 1

    # Reducimos la suma anterior para que el resultado quede dentro del cuerpo
    while suma >= 256:

        dif = len(bin(suma)[2:]) - len(bin(m)[2:])
        x = m << dif
        suma = suma ^ x

    return suma

# Entrada: a elemento del cuerpo representado por un entero entre 0 y 255
# Salida: True si a es generador del cuerpo, False si no lo es
def GF_es_generador(a):

    if a == 0 or a == 1:
        return False

    lista = set()
    potencia = a
    while potencia not in lista:

        lista.add(potencia)
        potencia = GF_product_p(potencia, a)

    if len(lista) == 255:
        return True

    return False

# Entrada: entero entre 256 y 511
# Salida: True si es irreducible y False si no lo es
def es_irreducible(limit):

    # Comprobamos si tiene algun divisor que no sea el 1 o el mismo
    for i in range(2, limit):

        x = limit

        # Reducimos limit hasta que sea más pequeño que el posible divisor
        while x >= i:

            dif = len(bin(x)[2:]) - len(bin(i)[2:])
            y = i << dif
            x = x ^ y

        if x == 0:
            return False

    # Si el residuo ha resultado no ser 0 en ninguno de los casos es irreducible
    return True

# Entrada:
# Salida: lista de polinomios binarios irreducibles de grado 8 representados como enteros
#         entre 256 y 511
def irreducible_polynomials():

    irreducibles = []

    for i in range(256,512):

        if es_irreducible(i):
            irreducibles.append(i)

    return irreducibles

(tablaExp, tablaLog) = GF_tables() # Situado aqui para ahorrar tiempo de ejecucion
                                   # en GF_product_t() y GF_invers()

# INSERTE AQUÍ LO QUE QUIERA PROBAR
print(irreducible_polynomials())

# Caso 1: GF_product_p vs GF_product_t
t = time.time()
for i in range(256):
    for j in range(256):
        result = GF_product_p(i,j)
print("GF_product_p ->" , time.time() - t)

t = time.time()
for i in range(256):
    for j in range(256):
        result = GF_product_t(i,j)
print("GF_product_t ->" , time.time() - t)

# Caso 2: GF_product_p(a,2) vs GF_product_t(a,2)
t = time.time()
for i in range(256):
    result = GF_product_p(i,2)
print("GF_product_p(a,2) ->" , time.time() - t)

t = time.time()
for i in range(256):
    result = GF_product_t(i,2)
print("GF_product_t(a,2) ->" , time.time() - t)

# Caso 3: GF_product_p(a,3) vs GF_product_t(a,3)
t = time.time()
for i in range(256):
    result = GF_product_p(i,3)
print("GF_product_p(a,3) ->" , time.time() - t)

t = time.time()
for i in range(256):
    result = GF_product_t(i,3)
print("GF_product_t(a,3) ->" , time.time() - t)

# Caso 4: GF_product_p(a,9) vs GF_product_t(a,9)
t = time.time()
for i in range(256):
    result = GF_product_p(i,9)
print("GF_product_p(a,9) ->" , time.time() - t)

t = time.time()
for i in range(256):
    result = GF_product_t(i,9)
print("GF_product_t(a,9) ->" , time.time() - t)

# Caso 5: GF_product_p(a,11) vs GF_product_t(a,11)
t = time.time()
for i in range(256):
    result = GF_product_p(i,11)
print("GF_product_p(a,11) ->" , time.time() - t)

t = time.time()
for i in range(256):
    result = GF_product_t(i,11)
print("GF_product_t(a,11) ->" , time.time() - t)

# Caso 6: GF_product_p(a,13) vs GF_product_t(a,13)
t = time.time()
for i in range(256):
    result = GF_product_p(i,13)
print("GF_product_p(a,13) ->" , time.time() - t)

t = time.time()
for i in range(256):
    result = GF_product_t(i,13)
print("GF_product_t(a,13) ->" , time.time() - t)

# Caso 7: GF_product_p(a,14) vs GF_product_t(a,14)
t = time.time()
for i in range(256):
    result = GF_product_p(i,14)
print("GF_product_p(a,14) ->" , time.time() - t)

t = time.time()
for i in range(256):
    result = GF_product_t(i,14)
print("GF_product_t(a,14) ->" , time.time() - t)