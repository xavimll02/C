import binascii
from Crypto.Cipher import AES
import hashlib
import filetype

plaintext_file = open("plaintext2", "wb")
ciphertext_file = open("AES_xavier.marti.llull_2022_09_20_16_59_14.puerta_trasera.enc","rb")
ciphertext = b"".join(ciphertext_file)

for i in range(0,32768):    # Probamos todos los casos posibles de PreMasterKey

    candidato = str(bin(i))[2:].zfill(16)   # Representado en binario con 16 bits
    pm = candidato[:8]  # primera mitad
    sm = candidato[8:]  # segunda mitad
    candidato = pm+pm+pm+pm+pm+pm+pm+candidato+sm+sm+sm+sm+sm+sm+sm # Expandimos, esto sería PreMasterKey como tal
    candidato_hex = '%0*X' % ((len(candidato) + 3) // 4, int(candidato, 2)) # Convertimos bit string a hex string
    candidato = binascii.a2b_hex(candidato_hex) # Convertimos hex string a ascii bytearray
    candidato_hashed = hashlib.sha256(candidato).hexdigest() # Calculamos sha256 y obtenemos un hex string
    key = bytearray.fromhex(candidato_hashed[:32]) # Cogemos la primera mitad de H y la asignamos a key como un bytearray
    nonce = bytearray.fromhex(candidato_hashed[32:]) # Cogemos la segunda mitad de H y la asignamos al nonce como bytearray
    cipher = AES.new(key, AES.MODE_CBC, nonce)
    plaintext = cipher.decrypt(ciphertext)
    
    # Esta parte no esta parametrizada, previamente he identificado en que caso se repetian bytes y cuantos (13)
    if plaintext[len(plaintext)-1] == plaintext[len(plaintext)-2] and plaintext[len(plaintext)-2] == plaintext[len(plaintext)-3]:

        print("We have finished at iteration", i)
        plaintext = plaintext[:557363]
        plaintext_file.write(plaintext)
        print(filetype.guess("plaintext2"))
        break




